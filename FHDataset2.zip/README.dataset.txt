# Frisbee CV > 2025-05-27 12:46pm
https://universe.roboflow.com/frisbee-cv/frisbee-cv

Provided by a Roboflow user
License: CC BY 4.0

